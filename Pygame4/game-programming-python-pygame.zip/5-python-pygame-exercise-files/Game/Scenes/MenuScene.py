from Game.Scenes.Scene import Scene

class MenuScene(Scene):

     def __init__(self, game):
         super(MenuScene, self).__init__(game)