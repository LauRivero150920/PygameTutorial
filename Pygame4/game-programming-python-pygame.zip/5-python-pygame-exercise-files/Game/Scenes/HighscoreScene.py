from Game.Scenes.Scene import Scene

class HighscoreScene(Scene):

     def __init__(self, game):
         super(HighscoreScene, self).__init__(game)