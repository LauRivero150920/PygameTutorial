from Game.Scenes.Scene import Scene

class GameOverScene(Scene):

     def __init__(self, game):
         super(GameOverScene, self).__init__(game)