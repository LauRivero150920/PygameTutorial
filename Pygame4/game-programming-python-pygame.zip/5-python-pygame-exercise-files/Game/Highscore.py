
class Highscore:

    def __init__(self):
        pass

    def getScores(self):
        pass

    def load(self):
        pass

    def add(self, name, score):
        pass
