from Game.Bricks.Brick import Brick
from Game.Bricks.LifeBrick import LifeBrick
from Game.Bricks.SpeedBrick import SpeedBrick