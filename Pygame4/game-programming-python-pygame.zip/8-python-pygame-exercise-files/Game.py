from Game import *

Breakout().start()
