y=20

def func(x):
    if x == 10 or y == 20:
        print("Wow that is a low value..")
    elif x == 20:
        print("Still not there..")
    else:
        print("Oh wel..")

func(20)
func(20)
func(1)