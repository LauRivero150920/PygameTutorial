data = []

data.append("Filip")
data.append(10)

print(data)

data.pop()

print(data)
data.append("Filip")
filips=data.count("Filip")
print(filips)

data.append("Sofie")

print(data)

data.reverse()

print(data)